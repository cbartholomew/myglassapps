var searchData=
[
  ['patch',['Patch',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1TimelineResource.html#a85362a89b11435f82e99d977369b51f0',1,'Google::Apis::Mirror::v1::TimelineResource.Patch()'],['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1ContactsResource.html#aeb7e68f27b3eb4da283150cd000f0d32',1,'Google::Apis::Mirror::v1::ContactsResource.Patch()']]]
];
