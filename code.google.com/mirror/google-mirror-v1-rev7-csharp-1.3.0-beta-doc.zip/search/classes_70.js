var searchData=
[
  ['patchrequest',['PatchRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1TimelineResource_1_1PatchRequest.html',1,'Google::Apis::Mirror::v1::TimelineResource']]],
  ['patchrequest',['PatchRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1ContactsResource_1_1PatchRequest.html',1,'Google::Apis::Mirror::v1::ContactsResource']]]
];
