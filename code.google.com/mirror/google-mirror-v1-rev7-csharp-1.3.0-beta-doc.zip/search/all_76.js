var searchData=
[
  ['values',['Values',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1MenuItem.html#ac499b1aaa93ce833a6d9eb20eaba43fe',1,'Google::Apis::Mirror::v1::Data::MenuItem']]],
  ['verifytoken',['VerifyToken',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1Notification.html#ad08a04a4dee77ceb045715445d3a446a',1,'Google::Apis::Mirror::v1::Data::Notification.VerifyToken()'],['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1Subscription.html#ae49bf53e58f0948fa2e856d44dd2fcc8',1,'Google::Apis::Mirror::v1::Data::Subscription.VerifyToken()']]]
];
