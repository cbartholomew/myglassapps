var searchData=
[
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1SubscriptionsResource_1_1DeleteRequest.html',1,'Google::Apis::Mirror::v1::SubscriptionsResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1TimelineResource_1_1DeleteRequest.html',1,'Google::Apis::Mirror::v1::TimelineResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1ContactsResource_1_1DeleteRequest.html',1,'Google::Apis::Mirror::v1::ContactsResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1TimelineResource_1_1AttachmentsResource_1_1DeleteRequest.html',1,'Google::Apis::Mirror::v1::TimelineResource::AttachmentsResource']]]
];
