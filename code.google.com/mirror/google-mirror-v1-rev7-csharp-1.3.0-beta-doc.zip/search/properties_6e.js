var searchData=
[
  ['nextpagetoken',['NextPageToken',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1TimelineListResponse.html#a7a9b4e07ea3e113e2ed53d093e48dfa0',1,'Google::Apis::Mirror::v1::Data::TimelineListResponse']]],
  ['notification',['Notification',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1TimelineItem.html#a6c81a631a93c0ad736738e8aa547babe',1,'Google::Apis::Mirror::v1::Data::TimelineItem.Notification()'],['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1Subscription.html#af3f954d38bd60015696aa5a177e8b157',1,'Google::Apis::Mirror::v1::Data::Subscription.Notification()']]]
];
