var searchData=
[
  ['subscription',['Subscription',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1Subscription.html',1,'Google::Apis::Mirror::v1::Data']]],
  ['subscriptionslistresponse',['SubscriptionsListResponse',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1SubscriptionsListResponse.html',1,'Google::Apis::Mirror::v1::Data']]],
  ['subscriptionsresource',['SubscriptionsResource',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1SubscriptionsResource.html',1,'Google::Apis::Mirror::v1']]]
];
