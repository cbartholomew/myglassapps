var searchData=
[
  ['menuitem',['MenuItem',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1MenuItem.html',1,'Google::Apis::Mirror::v1::Data']]],
  ['menuvalue',['MenuValue',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1MenuValue.html',1,'Google::Apis::Mirror::v1::Data']]],
  ['mirrorservice',['MirrorService',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1MirrorService.html',1,'Google::Apis::Mirror::v1']]]
];
