var searchData=
[
  ['notification',['Notification',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1Notification.html',1,'Google::Apis::Mirror::v1::Data']]],
  ['notificationconfig',['NotificationConfig',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1NotificationConfig.html',1,'Google::Apis::Mirror::v1::Data']]]
];
