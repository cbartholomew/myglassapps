var searchData=
[
  ['updatemediaupload',['UpdateMediaUpload',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1TimelineResource_1_1UpdateMediaUpload.html',1,'Google::Apis::Mirror::v1::TimelineResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1TimelineResource_1_1UpdateRequest.html',1,'Google::Apis::Mirror::v1::TimelineResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1ContactsResource_1_1UpdateRequest.html',1,'Google::Apis::Mirror::v1::ContactsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1SubscriptionsResource_1_1UpdateRequest.html',1,'Google::Apis::Mirror::v1::SubscriptionsResource']]],
  ['useraction',['UserAction',['../classGoogle_1_1Apis_1_1Mirror_1_1v1_1_1Data_1_1UserAction.html',1,'Google::Apis::Mirror::v1::Data']]]
];
