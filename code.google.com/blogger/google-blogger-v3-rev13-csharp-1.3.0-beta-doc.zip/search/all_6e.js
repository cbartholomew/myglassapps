var searchData=
[
  ['name',['Name',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Blog.html#a3afa41d54c17f13491516d2e8c7d1e84',1,'Google::Apis::Blogger::v3::Data::Blog.Name()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Post_1_1LocationData.html#a13f233f574c7e57cfa9d46c6bca26365',1,'Google::Apis::Blogger::v3::Data::Post::LocationData.Name()']]],
  ['nextpagetoken',['NextPageToken',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1CommentList.html#a8b921326c22296f81528566b0e402b18',1,'Google::Apis::Blogger::v3::Data::CommentList.NextPageToken()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1PostList.html#ab9efd09765a9c4a39e324a58e99a9dfa',1,'Google::Apis::Blogger::v3::Data::PostList.NextPageToken()']]]
];
