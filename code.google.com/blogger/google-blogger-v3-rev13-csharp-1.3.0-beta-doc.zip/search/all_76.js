var searchData=
[
  ['variant',['Variant',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Blog_1_1LocaleData.html#ab7a16d2fc701029788d9a0614d194f5d',1,'Google::Apis::Blogger::v3::Data::Blog::LocaleData.Variant()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1User_1_1LocaleData.html#a3c298072cd5507bc3fd9e716375b172f',1,'Google::Apis::Blogger::v3::Data::User::LocaleData.Variant()']]]
];
