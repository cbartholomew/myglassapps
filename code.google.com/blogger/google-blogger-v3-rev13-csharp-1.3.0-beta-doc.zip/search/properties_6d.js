var searchData=
[
  ['maxcomments',['MaxComments',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1PostsResource_1_1GetRequest.html#a9fb3a88bac8b27a42004d880e54ae391',1,'Google::Apis::Blogger::v3::PostsResource::GetRequest.MaxComments()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1PostsResource_1_1GetByPathRequest.html#a01013438cc6da5651c33fd56dbcd2ef3',1,'Google::Apis::Blogger::v3::PostsResource::GetByPathRequest.MaxComments()']]],
  ['maxposts',['MaxPosts',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1BlogsResource_1_1GetRequest.html#a33e22e44ac7f4588ba300e5d9dc2b4e7',1,'Google::Apis::Blogger::v3::BlogsResource::GetRequest']]],
  ['maxresults',['MaxResults',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1PostsResource_1_1ListRequest.html#a96e8018fcaec3cb34eadd06e61d33e41',1,'Google::Apis::Blogger::v3::PostsResource::ListRequest.MaxResults()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1CommentsResource_1_1ListRequest.html#a4ee3a4cd0dbef84afb2d6b654932a969',1,'Google::Apis::Blogger::v3::CommentsResource::ListRequest.MaxResults()']]]
];
