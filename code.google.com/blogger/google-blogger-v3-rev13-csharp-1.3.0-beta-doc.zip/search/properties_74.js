var searchData=
[
  ['title',['Title',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Post.html#a2a349fb57bae5f8a5d59bc721c34c115',1,'Google::Apis::Blogger::v3::Data::Post.Title()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Page.html#a7746bdc30a1c731bd965b157d59ac85a',1,'Google::Apis::Blogger::v3::Data::Page.Title()']]],
  ['totalitems',['TotalItems',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Blog_1_1PostsData.html#ac31a7fb5dfdce724f6870dd7bc4e5f4c',1,'Google::Apis::Blogger::v3::Data::Blog::PostsData.TotalItems()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Blog_1_1PagesData.html#a68353f3f173c4ef54ded329f22cfa907',1,'Google::Apis::Blogger::v3::Data::Blog::PagesData.TotalItems()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Post_1_1RepliesData.html#a85e517beb3a605d417998b2210db4442',1,'Google::Apis::Blogger::v3::Data::Post::RepliesData.TotalItems()']]]
];
