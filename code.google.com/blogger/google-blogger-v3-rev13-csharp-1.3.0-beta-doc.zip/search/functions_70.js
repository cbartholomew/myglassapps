var searchData=
[
  ['patch',['Patch',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1PostsResource.html#ae888f63733aafc18c8bdb05932552ae0',1,'Google::Apis::Blogger::v3::PostsResource']]]
];
