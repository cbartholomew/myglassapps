var searchData=
[
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1PostsResource_1_1UpdateRequest.html',1,'Google::Apis::Blogger::v3::PostsResource']]],
  ['user',['User',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1User.html',1,'Google::Apis::Blogger::v3::Data']]],
  ['usersresource',['UsersResource',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1UsersResource.html',1,'Google::Apis::Blogger::v3']]]
];
