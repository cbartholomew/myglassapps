var searchData=
[
  ['replies',['Replies',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Post.html#af434bb3c84627aae539a4b6390d9871b',1,'Google::Apis::Blogger::v3::Data::Post']]],
  ['repliesdata',['RepliesData',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Post_1_1RepliesData.html',1,'Google::Apis::Blogger::v3::Data::Post']]]
];
