var searchData=
[
  ['authordata',['AuthorData',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Comment_1_1AuthorData.html',1,'Google::Apis::Blogger::v3::Data::Comment']]],
  ['authordata',['AuthorData',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Page_1_1AuthorData.html',1,'Google::Apis::Blogger::v3::Data::Page']]],
  ['authordata',['AuthorData',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Post_1_1AuthorData.html',1,'Google::Apis::Blogger::v3::Data::Post']]]
];
