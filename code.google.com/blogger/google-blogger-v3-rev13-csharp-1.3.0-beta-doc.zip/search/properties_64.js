var searchData=
[
  ['description',['Description',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Blog.html#a8e641bb4b902db0a01e1bb4dc05ef834',1,'Google::Apis::Blogger::v3::Data::Blog']]],
  ['displayname',['DisplayName',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Comment_1_1AuthorData.html#ae8115f19ba2cdf2a7abf9bffc085cf70',1,'Google::Apis::Blogger::v3::Data::Comment::AuthorData.DisplayName()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1User.html#a6ca060fa32728ba92b91e70c51307326',1,'Google::Apis::Blogger::v3::Data::User.DisplayName()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Post_1_1AuthorData.html#a5b70a8e3ea77f1fcdfd6130fccd16b79',1,'Google::Apis::Blogger::v3::Data::Post::AuthorData.DisplayName()'],['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Page_1_1AuthorData.html#a2340333ff0d91fbdfa5d6b56ccafcb92',1,'Google::Apis::Blogger::v3::Data::Page::AuthorData.DisplayName()']]]
];
