var searchData=
[
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1PostsResource_1_1DeleteRequest.html',1,'Google::Apis::Blogger::v3::PostsResource']]]
];
