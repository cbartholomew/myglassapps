var searchData=
[
  ['repliesdata',['RepliesData',['../classGoogle_1_1Apis_1_1Blogger_1_1v3_1_1Data_1_1Post_1_1RepliesData.html',1,'Google::Apis::Blogger::v3::Data::Post']]]
];
